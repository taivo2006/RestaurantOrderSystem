# Restaurant Order Management - Frontend (Django Skeleton)

This is a minimal Django-based frontend skeleton for the Restaurant Order Management System.
Features:
- Login page
- Role-based dashboard (waiter, kitchen, manager)
- Menu browsing and add to order
- Order summary / create order
- Kitchen dashboard (view & update item status)
- Payment stub

Setup:
1. Create virtualenv: `python -m venv venv && source venv/bin/activate`
2. Install: `pip install -r requirements.txt`
3. Run: `python manage.py migrate` then `python manage.py runserver`
