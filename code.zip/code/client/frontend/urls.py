from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('menu/', views.menu_page, name='menu'),
    path('order/create/', views.create_order, name='create_order'),
    path('order/add/', views.add_to_order, name='add_to_order'),
    path('order/set/<int:order_id>/', views.set_order, name='set_order'),
    path('order/summary/', views.order_summary, name='order_summary'),
    path('order/submit/', views.submit_order, name='submit_order'),
    path('kitchen/', views.kitchen_dashboard, name='kitchen'),
    path('kitchen/orders/<int:order_id>/status/', views.update_kitchen_order_status, name='update_kitchen_order_status'),
    path('payment/', views.payment_page, name='payment'),
    path('menu/add-dish/', views.add_dish, name='add_dish'),
    path('logout/', views.logout_view, name='logout'),
]
