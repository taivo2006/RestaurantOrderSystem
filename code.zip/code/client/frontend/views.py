from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from services.api import api_get, api_post, api_put
import json

def _get_token(request):
    """Lấy token từ session"""
    return request.session.get('token')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        resp = api_post('/auth/login', {'username': username, 'password': password})
        if resp and resp.get('access_token'):
            access_token = resp.get('access_token')
            token_type = resp.get('token_type', 'bearer')
            # Lưu JWT vào session
            request.session['token'] = access_token
            request.session['token_type'] = token_type
            request.session['username'] = username
            # Mặc định role là waiter, có thể cập nhật từ API sau
            request.session['role'] = request.session.get('role', 'manage')
            return redirect('dashboard')
        else:
            return render(request, 'login.html', {'error': 'Sai tên đăng nhập hoặc mật khẩu'})
    return render(request, 'login.html')

def logout_view(request):
    request.session.flush()
    return redirect('login')

def dashboard(request):
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    role = request.session.get('role', 'waiter')
    if role == 'kitchen':
        return redirect('kitchen')
    elif role == 'manager':
        return render(request, 'dashboard_manager.html', {'username': request.session.get('username')})
    else:
        # Lấy danh sách bàn từ API
        tables_resp = api_get('/tables/', token)
        tables = []
        if tables_resp and 'tables' in tables_resp:
            tables = tables_resp['tables']
        elif tables_resp is None:
            # API call failed
            return render(request, 'dashboard_waiter.html', {
                'username': request.session.get('username'),
                'tables': [],
                'error': 'Không thể kết nối đến server. Vui lòng thử lại.'
            })
        
        # Lấy thống kê từ API
        stats_resp = api_get('/stats/dashboard', token)
        stats_data = {}
        if stats_resp:
            stats_data = {
                'orders_today': stats_resp.get('orders_today', 0),
                'occupied_tables': stats_resp.get('occupied_tables', 0),
                'total_tables': stats_resp.get('total_tables', 0),
                'pending_orders': stats_resp.get('pending_orders', 0),
                'revenue_today': stats_resp.get('revenue_today', 0)
            }
        
        return render(request, 'dashboard_waiter.html', {
            'username': request.session.get('username'),
            'tables': tables,
            'stats': stats_data
        })

def menu_page(request):
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    # Lấy menu từ API
    resp = api_get('/menu/dishes', token)
    dishes = []
    if resp and 'dishes' in resp:
        dishes = resp['dishes']
    
    # Lấy categories
    categories = list(set([d.get('category', 'Other') for d in dishes]))
    
    return render(request, 'menu.html', {
        'dishes': dishes,
        'categories': categories
    })

def create_order(request):
    """Tạo order mới cho bàn"""
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    if request.method == 'POST':
        table_id = int(request.POST.get('table_id', 1))
        staff_id = int(request.session.get('staff_id', 1))  # Có thể lấy từ session
        
        order_data = {
            'table_id': table_id,
            'staff_id': staff_id
        }
        
        resp = api_post('/orders/', order_data, token)
        if resp and 'order_id' in resp:
            order_id = resp['order_id']
            request.session['current_order_id'] = order_id
            
            # Cập nhật trạng thái bàn thành "occupied"
            table_status_data = {
                'status': 'occupied',
                'order_id': order_id
            }
            api_put(f'/tables/{table_id}/status', table_status_data, token)
            
            return redirect('menu')
        else:
            # Lấy lại danh sách bàn để hiển thị
            tables_resp = api_get('/tables/', token)
            tables = []
            if tables_resp and 'tables' in tables_resp:
                tables = tables_resp['tables']
            
            return render(request, 'dashboard_waiter.html', {
                'error': 'Không thể tạo order',
                'username': request.session.get('username'),
                'tables': tables
            })
    
    return redirect('dashboard')

def add_to_order(request):
    """Thêm món vào order"""
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    if request.method == 'POST':
        order_id = request.session.get('current_order_id')
        if not order_id:
            return redirect('dashboard')
        
        # Lấy các món được chọn
        items = []
        for key, value in request.POST.items():
            if key.startswith('qty_') and int(value) > 0:
                dish_id = int(key.replace('qty_', ''))
                quantity = int(value)
                items.append({
                    'dish_id': dish_id,
                    'quantity': quantity,
                    'notes': request.POST.get(f'notes_{dish_id}', '')
                })
        
        if not items:
            # Lấy lại menu để hiển thị lỗi
            resp = api_get('/menu/dishes', token)
            dishes = []
            categories = []
            if resp and 'dishes' in resp:
                dishes = resp['dishes']
                categories = list(set([d.get('category', 'Other') for d in dishes]))
            
            return render(request, 'menu.html', {
                'error': 'Vui lòng chọn ít nhất một món',
                'dishes': dishes,
                'categories': categories
            })
        
        # Thêm từng món vào order
        errors = []
        for item in items:
            resp = api_post(f'/orders/{order_id}/items', item, token)
            if not resp:
                errors.append(f"Không thể thêm món ID {item['dish_id']}")
        
        if errors:
            # Lấy lại menu để hiển thị lỗi
            resp = api_get('/menu/dishes', token)
            dishes = []
            categories = []
            if resp and 'dishes' in resp:
                dishes = resp['dishes']
                categories = list(set([d.get('category', 'Other') for d in dishes]))
            
            return render(request, 'menu.html', {
                'error': '; '.join(errors),
                'dishes': dishes,
                'categories': categories
            })
        
        return redirect('order_summary')
    
    return redirect('menu')

def set_order(request, order_id):
    """Set order_id vào session để xem order từ bàn"""
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    request.session['current_order_id'] = int(order_id)
    next_url = request.GET.get('next', '')
    if next_url == '/menu/':
        return redirect('menu')
    elif next_url == '/payment/':
        return redirect('payment')
    else:
        return redirect('order_summary')

def order_summary(request):
    """Xem tóm tắt order"""
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    # Có thể lấy order_id từ session hoặc query parameter
    order_id = request.session.get('current_order_id')
    if not order_id:
        order_id = request.GET.get('order_id')
        if order_id:
            request.session['current_order_id'] = int(order_id)
        else:
            return redirect('dashboard')
    
    # Lấy thông tin bill từ API
    bill_resp = api_get(f'/payment/orders/{order_id}/bill', token)
    
    return render(request, 'order_summary.html', {
        'order_id': order_id,
        'bill': bill_resp
    })

def submit_order(request):
    """Gửi order xuống bếp"""
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    if request.method == 'POST':
        order_id = request.session.get('current_order_id')
        if not order_id:
            return redirect('dashboard')
        
        resp = api_post(f'/orders/{order_id}/submit-to-kitchen', {}, token)
        if resp:
            return redirect('dashboard')
        else:
            return render(request, 'order_summary.html', {
                'error': 'Không thể gửi order xuống bếp',
                'order_id': order_id
            })
    
    return redirect('order_summary')

def kitchen_dashboard(request):
    """Dashboard cho bếp"""
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    # Lấy danh sách orders từ API
    orders_resp = api_get('/kitchen/orders', token)
    orders = []
    if orders_resp and 'orders' in orders_resp:
        orders = orders_resp['orders']
    
    return render(request, 'dashboard_kitchen.html', {
        'orders': orders,
        'username': request.session.get('username')
    })

def update_kitchen_order_status(request, order_id):
    """Cập nhật trạng thái order từ bếp"""
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    if request.method == 'POST':
        new_status = request.POST.get('status')
        if not new_status:
            return redirect('kitchen')
        
        # Gọi API để cập nhật status
        resp = api_put(f'/kitchen/orders/{order_id}/status', {'status': new_status}, token)
        if resp:
            return redirect('kitchen')
        else:
            # Lấy lại orders để hiển thị lỗi
            orders_resp = api_get('/kitchen/orders', token)
            orders = []
            if orders_resp and 'orders' in orders_resp:
                orders = orders_resp['orders']
            
            return render(request, 'dashboard_kitchen.html', {
                'error': 'Không thể cập nhật trạng thái order',
                'orders': orders,
                'username': request.session.get('username')
            })
    
    return redirect('kitchen')

def payment_page(request):
    """Trang thanh toán"""
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    order_id = request.session.get('current_order_id')
    if not order_id:
        return redirect('dashboard')
    
    # Lấy thông tin bill
    bill_resp = api_get(f'/payment/orders/{order_id}/bill', token)
    
    if request.method == 'POST':
        payment_method = request.POST.get('payment_method', 'cash')
        amount_given = request.POST.get('amount_given')
        
        payment_data = {
            'payment_method': payment_method,
            'amount_given': float(amount_given) if amount_given else None
        }
        
        resp = api_post(f'/payment/orders/{order_id}/process', payment_data, token)
        if resp:
            # Xóa order khỏi session
            request.session.pop('current_order_id', None)
            return render(request, 'payment.html', {
                'success': True,
                'invoice': resp.get('invoice', {}),
                'order_id': order_id
            })
        else:
            return render(request, 'payment.html', {
                'error': 'Thanh toán thất bại',
                'bill': bill_resp,
                'order_id': order_id
            })
    
    return render(request, 'payment.html', {
        'bill': bill_resp,
        'order_id': order_id
    })

def add_dish(request):
    """Thêm món mới vào menu (Manager only)"""
    token = _get_token(request)
    if not token:
        return redirect('login')
    
    if request.method == 'POST':
        dish_data = {
            'name': request.POST.get('name'),
            'category': request.POST.get('category'),
            'price': float(request.POST.get('price', 0)),
            'description': request.POST.get('description', ''),
            'status': 'available'
        }
        
        resp = api_post('/menu/dishes', dish_data, token)
        if resp:
            return redirect('menu')
        else:
            return render(request, 'dashboard_manager.html', {
                'error': 'Không thể thêm món',
                'username': request.session.get('username')
            })
    
    return redirect('dashboard')
