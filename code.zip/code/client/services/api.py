import os
import requests

API_BASE = os.getenv("API_BASE", "http://host.docker.internal:8001")

def _headers(token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers

def api_get(path, token=None):
    try:
        if not path.startswith('/'):
            path = '/' + path
        r = requests.get(f"{API_BASE}{path}", headers=_headers(token))
        r.raise_for_status()
        return r.json()
    except requests.RequestException as e:
        print(f"GET {path} failed:", e)
        return None

def api_post(path, data, token=None):
    try:
        if not path.startswith('/'):
            path = '/' + path
        r = requests.post(f"{API_BASE}{path}", json=data, headers=_headers(token))
        r.raise_for_status()
        return r.json()
    except requests.RequestException as e:
        print(f"POST {path} failed:", e)
        return None

def api_put(path, data, token=None):
    try:
        if not path.startswith('/'):
            path = '/' + path
        r = requests.put(f"{API_BASE}{path}", json=data, headers=_headers(token))
        r.raise_for_status()
        return r.json()
    except requests.RequestException as e:
        print(f"PUT {path} failed:", e)
        return None
