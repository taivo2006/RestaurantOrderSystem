# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import auth, menu, orders, payment, tables, kitchen, stats

# Khởi tạo ứng dụng FastAPI
app = FastAPI(
    title="Restaurant Order Management API",
    description="API cho Đồ án môn học Công nghệ phần mềm.",
    version="1.0.0"
)

# CORS middleware để client có thể gọi API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Gắn các router từ các module vào ứng dụng chính
app.include_router(auth.router)
app.include_router(menu.router)
app.include_router(orders.router)
app.include_router(payment.router)
app.include_router(tables.router)
app.include_router(kitchen.router)
app.include_router(stats.router)

@app.get("/", tags=["Root"])
async def read_root():
    """
    API gốc để kiểm tra hệ thống có chạy hay không.
    """
    return {"message": "Welcome to the Restaurant Order Management API!"}