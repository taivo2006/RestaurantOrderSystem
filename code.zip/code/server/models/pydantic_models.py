# models/pydantic_models.py
from pydantic import BaseModel
from typing import List, Optional

# ============ Auth Models ============
class LoginRequest(BaseModel):
    username: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

# ============ Menu Models ============
class DishCreate(BaseModel):
    name: str
    category: str
    price: float
    description: Optional[str] = None
    status: str = "available"

# ============ Order Models ============
class OrderCreate(BaseModel):
    table_id: int
    staff_id: int

class OrderItemAdd(BaseModel):
    dish_id: int
    quantity: int
    notes: Optional[str] = None

# ============ Payment Models ============
class PaymentProcess(BaseModel):
    payment_method: str # "cash" hoặc "card"
    amount_given: Optional[float] = None # Dùng cho tiền mặt

# ============ Table Models ============
class TableStatusUpdate(BaseModel):
    status: str  # "available", "occupied", "reserved", "cleaning"
    order_id: Optional[int] = None

# ============ Kitchen Models ============
class OrderStatusUpdate(BaseModel):
    status: str  # "pending", "in_progress", "ready", "completed"