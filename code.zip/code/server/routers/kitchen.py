# routers/kitchen.py
from fastapi import APIRouter, HTTPException, status
from storage import get_orders_by_status, get_order_by_id
from models.pydantic_models import OrderStatusUpdate
from typing import Optional

router = APIRouter(prefix="/kitchen", tags=["Kitchen"])

@router.get("/orders", summary="Lấy danh sách orders cho bếp")
async def get_kitchen_orders(status: Optional[str] = None):
    """
    API lấy danh sách orders cho bếp xử lý.
    """
    if status:
        orders = get_orders_by_status(status)
    else:
        # Lấy orders đang chế biến hoặc chờ xử lý
        in_progress = get_orders_by_status("in_progress")
        pending = get_orders_by_status("pending")
        orders = pending + in_progress
    
    # Sắp xếp theo thời gian tạo
    orders.sort(key=lambda x: x.get("created_at", ""), reverse=False)
    
    return {"orders": orders}

@router.put("/orders/{order_id}/status", summary="Cập nhật trạng thái order")
async def update_order_status(order_id: int, status_update: OrderStatusUpdate):
    """
    API cập nhật trạng thái order (pending -> in_progress -> ready).
    """
    order = get_order_by_id(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    new_status = status_update.status
    valid_statuses = ["pending", "in_progress", "ready", "completed"]
    if new_status not in valid_statuses:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid status. Must be one of: {', '.join(valid_statuses)}"
        )
    
    from datetime import datetime
    order["status"] = new_status
    order["updated_at"] = datetime.now().isoformat()
    
    return {
        "message": "Order status updated successfully",
        "order_id": order_id,
        "status": new_status
    }

