# routers/menu.py
from fastapi import APIRouter, HTTPException, status
from models.pydantic_models import DishCreate
from storage import dishes_db
from typing import Optional

router = APIRouter(prefix="/menu", tags=["Menu"])

@router.get("/dishes", summary="Xem menu")
async def get_dishes(category: Optional[str] = None, search: Optional[str] = None):
    """
    API lấy danh sách món ăn, có thể lọc theo category hoặc tìm kiếm.
    """
    results = dishes_db.copy()
    
    if search:
        search_lower = search.lower()
        results = [d for d in results if search_lower in d['name'].lower() or 
                   (d.get('description') and search_lower in d['description'].lower())]
    
    if category:
        results = [d for d in results if d['category'] == category]
    
    return {"dishes": results}

@router.get("/dishes/{dish_id}", summary="Lấy thông tin món")
async def get_dish(dish_id: int):
    """
    API lấy thông tin chi tiết một món ăn.
    """
    dish = next((d for d in dishes_db if d["id"] == dish_id), None)
    if not dish:
        raise HTTPException(status_code=404, detail="Dish not found")
    
    return dish

@router.post("/dishes", status_code=status.HTTP_201_CREATED, summary="Thêm món mới")
async def create_dish(dish: DishCreate):
    """
    API thêm món ăn mới vào menu (Manager only).
    """
    # Tạo ID mới
    new_id = max([d["id"] for d in dishes_db], default=0) + 1
    
    new_dish = {
        "id": new_id,
        "name": dish.name,
        "category": dish.category,
        "price": dish.price,
        "description": dish.description,
        "status": dish.status
    }
    
    dishes_db.append(new_dish)
    return new_dish

@router.put("/dishes/{dish_id}", summary="Cập nhật món")
async def update_dish(dish_id: int, dish: DishCreate):
    """
    API cập nhật thông tin món ăn.
    """
    dish_to_update = next((d for d in dishes_db if d["id"] == dish_id), None)
    if not dish_to_update:
        raise HTTPException(status_code=404, detail="Dish not found")
    
    dish_to_update.update({
        "name": dish.name,
        "category": dish.category,
        "price": dish.price,
        "description": dish.description,
        "status": dish.status
    })
    
    return dish_to_update

@router.delete("/dishes/{dish_id}", summary="Xóa món")
async def delete_dish(dish_id: int):
    """
    API xóa món khỏi menu.
    """
    global dishes_db
    dish = next((d for d in dishes_db if d["id"] == dish_id), None)
    if not dish:
        raise HTTPException(status_code=404, detail="Dish not found")
    
    dishes_db = [d for d in dishes_db if d["id"] != dish_id]
    return {"message": "Dish deleted successfully"}
