# routers/orders.py
from fastapi import APIRouter, HTTPException, status
from models.pydantic_models import OrderCreate, OrderItemAdd
from storage import (
    orders_db, get_next_order_id, get_order_by_id, 
    get_dish_by_id, get_table_by_id, get_orders_by_status
)
from datetime import datetime
from typing import Optional

router = APIRouter(prefix="/orders", tags=["Orders"])

@router.post("/", status_code=status.HTTP_201_CREATED, summary="Tạo order mới")
async def create_new_order(order: OrderCreate):
    """
    API tạo một order mới cho bàn.
    """
    # Kiểm tra bàn có tồn tại không
    table = get_table_by_id(order.table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    
    # Kiểm tra bàn có đang trống không
    if table["status"] != "available":
        raise HTTPException(
            status_code=400, 
            detail=f"Table {order.table_id} is not available (current status: {table['status']})"
        )
    
    new_order_id = get_next_order_id()
    orders_db[new_order_id] = {
        "id": new_order_id,
        "table_id": order.table_id,
        "staff_id": order.staff_id,
        "items": [],
        "status": "pending",
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }
    
    return {
        "order_id": new_order_id,
        "status": "pending",
        "details": order.dict()
    }

@router.get("/{order_id}", summary="Lấy thông tin order")
async def get_order(order_id: int):
    """
    API lấy thông tin chi tiết của một order.
    """
    order = get_order_by_id(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    return order

@router.post("/{order_id}/items", status_code=status.HTTP_201_CREATED, summary="Thêm món vào order")
async def add_item_to_order(order_id: int, item: OrderItemAdd):
    """
    API thêm món ăn vào order.
    """
    order = get_order_by_id(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Kiểm tra order có thể thêm món không (chưa submit)
    if order["status"] not in ["pending", "draft"]:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot add items to order with status: {order['status']}"
        )
    
    # Kiểm tra món có tồn tại không
    dish = get_dish_by_id(item.dish_id)
    if not dish:
        raise HTTPException(status_code=404, detail="Dish not found")
    
    # Kiểm tra món có available không
    if dish["status"] != "available":
        raise HTTPException(
            status_code=400,
            detail=f"Dish {dish['name']} is not available"
        )
    
    # Thêm món vào order
    order_item = {
        "dish_id": item.dish_id,
        "dish_name": dish["name"],
        "quantity": item.quantity,
        "price": dish["price"],
        "notes": item.notes,
        "subtotal": dish["price"] * item.quantity
    }
    
    order["items"].append(order_item)
    order["updated_at"] = datetime.now().isoformat()
    
    return {"message": "Item added successfully", "order": order}

@router.post("/{order_id}/submit-to-kitchen", summary="Gửi order xuống bếp")
async def submit_order_to_kitchen(order_id: int):
    """
    API gửi order xuống bếp để chế biến.
    """
    order = get_order_by_id(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    if not order["items"]:
        raise HTTPException(status_code=400, detail="Cannot submit empty order")
    
    if order["status"] != "pending":
        raise HTTPException(
            status_code=400,
            detail=f"Order already submitted (current status: {order['status']})"
        )
    
    order["status"] = "in_progress"
    order["updated_at"] = datetime.now().isoformat()
    
    return {
        "message": "Order sent to kitchen successfully",
        "order_id": order_id,
        "status": "in_progress"
    }

@router.get("/", summary="Lấy danh sách orders")
async def get_orders(status: Optional[str] = None):
    """
    API lấy danh sách orders, có thể lọc theo status.
    """
    if status:
        orders = get_orders_by_status(status)
    else:
        orders = list(orders_db.values())
    
    return {"orders": orders}
