# routers/payment.py
from fastapi import APIRouter, HTTPException, status
from models.pydantic_models import PaymentProcess
from storage import get_order_by_id, get_table_by_id, tables_db
from datetime import datetime

router = APIRouter(prefix="/payment", tags=["Payment"])

VAT_RATE = 0.1  # 10% VAT

@router.get("/orders/{order_id}/bill", summary="Xem bill")
async def get_order_bill(order_id: int):
    """
    API lấy thông tin hóa đơn chi tiết của order.
    """
    order = get_order_by_id(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Tính toán bill từ items trong order
    items = []
    subtotal = 0.0
    
    for item in order.get("items", []):
        item_total = item["price"] * item["quantity"]
        subtotal += item_total
        items.append({
            "name": item["dish_name"],
            "quantity": item["quantity"],
            "price": item_total,
            "unit_price": item["price"]
        })
    
    vat = subtotal * VAT_RATE
    total_amount = subtotal + vat
    
    return {
        "order_id": order_id,
        "items": items,
        "subtotal": round(subtotal, 2),
        "vat": round(vat, 2),
        "total_amount": round(total_amount, 2)
    }

@router.post("/orders/{order_id}/process", summary="Xử lý thanh toán")
async def process_payment_for_order(order_id: int, payment: PaymentProcess):
    """
    API xử lý thanh toán cho order.
    """
    order = get_order_by_id(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Tính toán bill
    bill = await get_order_bill(order_id)
    total_amount = bill["total_amount"]
    
    # Kiểm tra payment method
    if payment.payment_method not in ["cash", "card"]:
        raise HTTPException(
            status_code=400,
            detail="Payment method must be 'cash' or 'card'"
        )
    
    # Nếu là tiền mặt, kiểm tra số tiền đưa
    if payment.payment_method == "cash":
        if not payment.amount_given:
            raise HTTPException(
                status_code=400,
                detail="amount_given is required for cash payment"
            )
        if payment.amount_given < total_amount:
            raise HTTPException(
                status_code=400,
                detail=f"Insufficient amount. Required: {total_amount}, Given: {payment.amount_given}"
            )
    
    # Cập nhật trạng thái order
    order["status"] = "paid"
    order["payment_method"] = payment.payment_method
    order["paid_amount"] = payment.amount_given if payment.payment_method == "cash" else total_amount
    order["paid_at"] = datetime.now().isoformat()
    order["updated_at"] = datetime.now().isoformat()
    
    # Cập nhật trạng thái bàn về available
    table = get_table_by_id(order["table_id"])
    if table:
        table["status"] = "available"
        table["current_order_id"] = None
    
    return {
        "message": "Payment processed successfully",
        "order_id": order_id,
        "status": "paid",
        "invoice": {
            "total_paid": total_amount,
            "method": payment.payment_method,
            "change": round(payment.amount_given - total_amount, 2) if payment.payment_method == "cash" else 0,
            "time": order["paid_at"]
        }
    }
