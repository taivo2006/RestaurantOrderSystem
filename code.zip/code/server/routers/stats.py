# routers/stats.py
from fastapi import APIRouter
from storage import orders_db, tables_db
from datetime import datetime, date

router = APIRouter(prefix="/stats", tags=["Stats"])

@router.get("/dashboard", summary="Lấy thống kê dashboard")
async def get_dashboard_stats():
    """
    API lấy thống kê cho dashboard: đơn hàng, bàn, doanh thu, đơn chờ xử lý.
    """
    today = date.today().isoformat()
    
    # Đếm đơn hàng hôm nay
    orders_today = [
        o for o in orders_db.values() 
        if o.get("created_at", "").startswith(today)
    ]
    total_orders_today = len(orders_today)
    
    # Đếm bàn đang phục vụ
    occupied_tables = [t for t in tables_db if t["status"] == "occupied"]
    total_tables = len(tables_db)
    occupied_count = len(occupied_tables)
    
    # Đếm đơn chờ xử lý
    pending_orders = [o for o in orders_db.values() if o.get("status") == "pending"]
    pending_count = len(pending_orders)
    
    # Tính doanh thu hôm nay (từ các order đã thanh toán)
    revenue_today = 0.0
    for order in orders_today:
        if order.get("status") == "paid":
            # Lấy từ paid_amount nếu có
            if order.get("paid_amount"):
                revenue_today += order.get("paid_amount")
            else:
                # Tính từ items trong order
                items = order.get("items", [])
                subtotal = sum(item.get("subtotal", 0) for item in items)
                vat = subtotal * 0.1  # 10% VAT
                revenue_today += subtotal + vat
    
    return {
        "orders_today": total_orders_today,
        "occupied_tables": occupied_count,
        "total_tables": total_tables,
        "pending_orders": pending_count,
        "revenue_today": round(revenue_today, 2)
    }

