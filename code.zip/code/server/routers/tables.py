# routers/tables.py
from fastapi import APIRouter, HTTPException, status
from models.pydantic_models import TableStatusUpdate
from storage import tables_db, get_table_by_id, get_orders_by_status
from typing import Optional

router = APIRouter(prefix="/tables", tags=["Tables"])

@router.get("/", summary="Lấy danh sách tất cả bàn")
async def get_all_tables(status_filter: Optional[str] = None):
    """
    API lấy danh sách tất cả bàn, có thể lọc theo trạng thái.
    """
    results = tables_db.copy()
    
    if status_filter:
        results = [t for t in results if t['status'] == status_filter]
    
    return {"tables": results}

@router.get("/{table_id}", summary="Lấy thông tin chi tiết bàn")
async def get_table(table_id: int):
    """
    API lấy thông tin chi tiết của một bàn.
    """
    table = get_table_by_id(table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    
    return table

@router.put("/{table_id}/status", summary="Cập nhật trạng thái bàn")
async def update_table_status(table_id: int, status_update: TableStatusUpdate):
    """
    API cập nhật trạng thái bàn.
    """
    table = get_table_by_id(table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    
    # Validate status
    valid_statuses = ["available", "occupied", "reserved", "cleaning"]
    if status_update.status not in valid_statuses:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid status. Must be one of: {', '.join(valid_statuses)}"
        )
    
    table["status"] = status_update.status
    if status_update.order_id:
        table["current_order_id"] = status_update.order_id
    elif status_update.status == "available":
        table["current_order_id"] = None
    
    return {"message": "Table status updated successfully", "table": table}

@router.get("/{table_id}/orders", summary="Lấy danh sách orders của bàn")
async def get_table_orders(table_id: int):
    """
    API lấy danh sách orders của một bàn.
    """
    table = get_table_by_id(table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    
    # Lấy tất cả orders của bàn này
    from storage import orders_db
    orders = [o for o in orders_db.values() if o["table_id"] == table_id]
    
    return {"table_id": table_id, "orders": orders}
