# storage.py - In-memory storage cho tất cả dữ liệu
from datetime import datetime
from typing import Dict, List, Optional

# ============ Users Storage ============
users_db: Dict[str, dict] = {
    "admin": {"id": 1, "username": "admin", "password": "admin123", "role": "manager"},
}

# ============ Menu Storage ============
dishes_db: List[dict] = [
    {"id": 1, "name": "Phở Bò", "category": "Main Course", "price": 50000.0, "status": "available", "description": "Phở bò truyền thống"},
    {"id": 2, "name": "Coca Cola", "category": "Beverages", "price": 15000.0, "status": "available", "description": "Nước ngọt có ga"},
    {"id": 3, "name": "Bánh Mì", "category": "Main Course", "price": 30000.0, "status": "available", "description": "Bánh mì thịt nướng"},
    {"id": 4, "name": "Bún Chả", "category": "Main Course", "price": 45000.0, "status": "available", "description": "Bún chả Hà Nội"},
    {"id": 5, "name": "Trà Đá", "category": "Beverages", "price": 10000.0, "status": "available", "description": "Trà đá vỉa hè"},
]

# ============ Tables Storage ============
tables_db: List[dict] = [
    {"id": 1, "number": 1, "capacity": 4, "status": "available", "current_order_id": None},
    {"id": 2, "number": 2, "capacity": 4, "status": "available", "current_order_id": None},
    {"id": 3, "number": 3, "capacity": 6, "status": "available", "current_order_id": None},
    {"id": 4, "number": 4, "capacity": 2, "status": "available", "current_order_id": None},
    {"id": 5, "number": 5, "capacity": 4, "status": "available", "current_order_id": None},
    {"id": 6, "number": 6, "capacity": 6, "status": "available", "current_order_id": None},
]

# ============ Orders Storage ============
orders_db: Dict[int, dict] = {}
order_counter = 0

def get_next_order_id() -> int:
    global order_counter
    order_counter += 1
    return order_counter

# ============ Helper Functions ============
def get_user_by_username(username: str) -> Optional[dict]:
    return users_db.get(username)

def get_dish_by_id(dish_id: int) -> Optional[dict]:
    return next((d for d in dishes_db if d["id"] == dish_id), None)

def get_table_by_id(table_id: int) -> Optional[dict]:
    return next((t for t in tables_db if t["id"] == table_id), None)

def get_order_by_id(order_id: int) -> Optional[dict]:
    return orders_db.get(order_id)

def get_orders_by_status(status: str) -> List[dict]:
    return [o for o in orders_db.values() if o.get("status") == status]

